Convert the below HTML/CSS code into React components:

